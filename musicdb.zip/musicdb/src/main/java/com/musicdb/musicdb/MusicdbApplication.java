package com.musicdb.musicdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicdbApplication.class, args);
	}

}
